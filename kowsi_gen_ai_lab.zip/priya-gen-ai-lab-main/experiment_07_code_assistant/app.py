"""Experiment 7: code generation and debugging using Salesforce CodeGen."""

from transformers import AutoModelForCausalLM, AutoTokenizer


MODEL_NAME = "Salesforce/codegen-350M-mono"


def main() -> None:
    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
    model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)

    def generate_code(prompt: str, max_new_tokens: int = 80) -> str:
        input_ids = tokenizer(prompt, return_tensors="pt").input_ids
        output = model.generate(
            input_ids,
            max_new_tokens=max_new_tokens,
            pad_token_id=tokenizer.eos_token_id,
            do_sample=False,
        )
        return tokenizer.decode(output[0], skip_special_tokens=True)

    prime_prompt = "# Write a Python function to check if a number is prime\ndef is_prime(n):"
    print("Generated function:\n", generate_code(prime_prompt))

    buggy_prompt = """# Fix the bug in this factorial function.
def factorial(n):
    result = 0
    for i in range(1, n + 1):
        result *= i
    return result

# Corrected function:
def factorial_fixed(n):"""
    print("\nDebug suggestion:\n", generate_code(buggy_prompt, max_new_tokens=60))


if __name__ == "__main__":
    main()

