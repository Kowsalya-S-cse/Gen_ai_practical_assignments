"""Experiment 8: text-to-image generation using Stable Diffusion."""

import torch
from diffusers import StableDiffusionPipeline


def main() -> None:
    if not torch.cuda.is_available():
        raise RuntimeError("A CUDA GPU is required for this experiment.")
    pipe = StableDiffusionPipeline.from_pretrained(
        "runwayml/stable-diffusion-v1-5", torch_dtype=torch.float16
    ).to("cuda")
    prompt = "A futuristic city skyline at sunset, digital art, highly detailed"
    image = pipe(prompt, num_inference_steps=30, guidance_scale=7.5).images[0]
    image.save("generated_city.png")
    print("Image generated and saved as generated_city.png")


if __name__ == "__main__":
    main()

