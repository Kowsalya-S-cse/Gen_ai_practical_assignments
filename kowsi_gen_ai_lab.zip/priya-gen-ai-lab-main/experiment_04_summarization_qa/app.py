"""Experiment 4: abstractive summarization and extractive question answering."""

from transformers import pipeline


ARTICLE = """Generative AI refers to artificial-intelligence models capable of
producing new content such as text, images, audio, and video. Large Language Models
such as GPT and LLaMA are trained on massive text corpora and can perform natural
language tasks including translation, summarization, and question answering. These
models are increasingly used in customer support and software development."""


def main() -> None:
    summarizer = pipeline("summarization", model="facebook/bart-large-cnn")
    summary = summarizer(ARTICLE, max_length=45, min_length=20, do_sample=False)[0]
    print("Summary:\n", summary["summary_text"])

    qa = pipeline("question-answering", model="distilbert-base-cased-distilled-squad")
    question = "What are Large Language Models trained on?"
    answer = qa(question=question, context=ARTICLE)
    print(f"\nQuestion: {question}")
    print(f"Answer: {answer['answer']} | Confidence: {answer['score']:.3f}")


if __name__ == "__main__":
    main()

