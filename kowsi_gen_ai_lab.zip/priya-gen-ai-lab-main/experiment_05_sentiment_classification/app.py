"""Experiment 5: sentiment analysis and zero-shot document classification."""

from transformers import pipeline


def main() -> None:
    sentiment_analyzer = pipeline("sentiment-analysis")
    reviews = [
        "The new smartphone has an amazing camera and battery life!",
        "The delivery was late and the packaging was damaged.",
    ]
    for review in reviews:
        result = sentiment_analyzer(review)[0]
        print(f"Review: {review}\n-> {result['label']} ({result['score']:.3f})\n")

    classifier = pipeline("zero-shot-classification", model="facebook/bart-large-mnli")
    document = "The central bank raised interest rates to control rising inflation."
    result = classifier(document, ["Politics", "Economy", "Sports", "Technology"])
    print("Document:", document)
    for label, score in zip(result["labels"], result["scores"]):
        print(f"{label}: {score:.3f}")


if __name__ == "__main__":
    main()

