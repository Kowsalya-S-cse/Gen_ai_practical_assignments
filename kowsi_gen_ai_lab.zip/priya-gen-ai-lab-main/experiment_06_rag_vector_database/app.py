"""Experiment 6: retrieval-augmented generation with FAISS."""

import faiss
import numpy as np
from sentence_transformers import SentenceTransformer
from transformers import pipeline


DOCUMENTS = [
    "The Eiffel Tower is located in Paris, France and was completed in 1889.",
    "Retrieval-Augmented Generation combines document retrieval with text generation.",
    "Python is a high-level programming language widely used in AI development.",
    "Vector databases store embeddings and support fast similarity search.",
]


def main() -> None:
    embedder = SentenceTransformer("all-MiniLM-L6-v2")
    document_vectors = np.asarray(embedder.encode(DOCUMENTS), dtype="float32")
    index = faiss.IndexFlatL2(document_vectors.shape[1])
    index.add(document_vectors)

    query = "What is RAG in AI?"
    query_vector = np.asarray(embedder.encode([query]), dtype="float32")
    _, indices = index.search(query_vector, k=2)
    retrieved = [DOCUMENTS[index] for index in indices[0]]
    context = "\n".join(retrieved)

    generator = pipeline("text2text-generation", model="google/flan-t5-base")
    prompt = f"Answer using only the context.\nContext:\n{context}\nQuestion: {query}"
    answer = generator(prompt, max_new_tokens=80, do_sample=False)[0]["generated_text"]
    print("Retrieved context:\n", context)
    print("\nAnswer:\n", answer)


if __name__ == "__main__":
    main()

