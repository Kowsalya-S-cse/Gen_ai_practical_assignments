"""Experiment 3: multi-turn conversational chatbot using DialoGPT."""

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer


def main() -> None:
    model_name = "microsoft/DialoGPT-medium"
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForCausalLM.from_pretrained(model_name)
    chat_history_ids = None
    print("Chatbot ready. Type 'quit' to exit.")

    for _ in range(5):
        user_input = input(">> User: ").strip()
        if user_input.lower() == "quit":
            break
        new_input_ids = tokenizer.encode(
            user_input + tokenizer.eos_token, return_tensors="pt"
        )
        bot_input_ids = (
            torch.cat([chat_history_ids, new_input_ids], dim=-1)
            if chat_history_ids is not None
            else new_input_ids
        )
        chat_history_ids = model.generate(
            bot_input_ids,
            max_new_tokens=80,
            pad_token_id=tokenizer.eos_token_id,
            do_sample=True,
            top_k=50,
            top_p=0.9,
        )
        response_tokens = chat_history_ids[:, bot_input_ids.shape[-1] :][0]
        print("Bot:", tokenizer.decode(response_tokens, skip_special_tokens=True))


if __name__ == "__main__":
    main()

