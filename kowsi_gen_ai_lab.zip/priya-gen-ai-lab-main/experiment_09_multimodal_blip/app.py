"""Experiment 9: image captioning and visual question answering using BLIP."""

from io import BytesIO

import requests
from PIL import Image
from transformers import (
    BlipForConditionalGeneration,
    BlipForQuestionAnswering,
    BlipProcessor,
)


IMAGE_URL = "https://images.unsplash.com/photo-1519125323398-675f0ddb6308"


def main() -> None:
    response = requests.get(IMAGE_URL, timeout=30)
    response.raise_for_status()
    image = Image.open(BytesIO(response.content)).convert("RGB")

    caption_processor = BlipProcessor.from_pretrained(
        "Salesforce/blip-image-captioning-base"
    )
    caption_model = BlipForConditionalGeneration.from_pretrained(
        "Salesforce/blip-image-captioning-base"
    )
    caption_inputs = caption_processor(image, return_tensors="pt")
    caption_ids = caption_model.generate(**caption_inputs, max_new_tokens=30)
    caption = caption_processor.decode(caption_ids[0], skip_special_tokens=True)
    print("Generated caption:", caption)

    vqa_processor = BlipProcessor.from_pretrained("Salesforce/blip-vqa-base")
    vqa_model = BlipForQuestionAnswering.from_pretrained("Salesforce/blip-vqa-base")
    question = "What animal is in the picture?"
    vqa_inputs = vqa_processor(image, question, return_tensors="pt")
    answer_ids = vqa_model.generate(**vqa_inputs)
    answer = vqa_processor.decode(answer_ids[0], skip_special_tokens=True)
    print("Question:", question)
    print("Answer:", answer)


if __name__ == "__main__":
    main()

