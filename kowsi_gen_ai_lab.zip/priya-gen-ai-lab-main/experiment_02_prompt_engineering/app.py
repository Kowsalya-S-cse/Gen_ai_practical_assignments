"""Experiment 2: compare zero-shot, few-shot and chain-of-thought prompts."""

from transformers import pipeline


def main() -> None:
    generator = pipeline("text-generation", model="gpt2")
    prompts = {
        "Zero-shot": (
            "Classify the sentiment as Positive or Negative.\n"
            "Review: The product quality is excellent!\nSentiment:"
        ),
        "Few-shot": (
            "Review: I loved this movie; it was fantastic.\nSentiment: Positive\n"
            "Review: The service was slow and disappointing.\nSentiment: Negative\n"
            "Review: The product quality is excellent!\nSentiment:"
        ),
        "Chain-of-Thought": (
            "Q: A shop had 15 apples. It sold 6 and received 10 more. How many now?\n"
            "A: 15 - 6 = 9. 9 + 10 = 19. The answer is 19.\n"
            "Q: A library had 120 books. It lent out 45 and bought 30. How many now?\n"
            "A: Let's solve it step by step."
        ),
    }
    for name, prompt in prompts.items():
        output = generator(
            prompt,
            max_new_tokens=40,
            do_sample=False,
            pad_token_id=generator.tokenizer.eos_token_id,
        )[0]["generated_text"]
        print(f"=== {name} ===\n{output}\n")


if __name__ == "__main__":
    main()

