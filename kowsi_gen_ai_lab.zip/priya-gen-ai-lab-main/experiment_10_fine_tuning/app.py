"""Experiment 10: fine-tune DistilBERT for IMDB sentiment classification."""

import numpy as np
from datasets import load_dataset
from sklearn.metrics import accuracy_score
from transformers import (
    AutoModelForSequenceClassification,
    AutoTokenizer,
    Trainer,
    TrainingArguments,
)


def main() -> None:
    dataset = load_dataset("imdb")
    train_data = dataset["train"].shuffle(seed=42).select(range(2000))
    test_data = dataset["test"].shuffle(seed=42).select(range(500))
    tokenizer = AutoTokenizer.from_pretrained("distilbert-base-uncased")

    def tokenize(batch):
        return tokenizer(
            batch["text"], padding="max_length", truncation=True, max_length=128
        )

    train_data = train_data.map(tokenize, batched=True)
    test_data = test_data.map(tokenize, batched=True)
    model = AutoModelForSequenceClassification.from_pretrained(
        "distilbert-base-uncased", num_labels=2
    )
    arguments = TrainingArguments(
        output_dir="./results",
        num_train_epochs=2,
        per_device_train_batch_size=8,
        per_device_eval_batch_size=8,
        eval_strategy="epoch",
        save_strategy="epoch",
        logging_steps=50,
        report_to="none",
    )

    def compute_metrics(prediction):
        predicted_labels = np.argmax(prediction.predictions, axis=1)
        return {"accuracy": accuracy_score(prediction.label_ids, predicted_labels)}

    trainer = Trainer(
        model=model,
        args=arguments,
        train_dataset=train_data,
        eval_dataset=test_data,
        compute_metrics=compute_metrics,
    )
    trainer.train()
    print("Evaluation metrics:", trainer.evaluate())
    trainer.save_model("./fine_tuned_distilbert_imdb")


if __name__ == "__main__":
    main()

