"""Experiment 11: generate related text, image and audio content."""

import torch
from diffusers import StableDiffusionPipeline
from gtts import gTTS
from transformers import pipeline


def main() -> None:
    if not torch.cuda.is_available():
        raise RuntimeError("A CUDA GPU is required for the image-generation stage.")
    topic = "The benefits of renewable energy"

    text_generator = pipeline("text2text-generation", model="google/flan-t5-base")
    prompt = f"Write a short, engaging paragraph about: {topic}"
    generated_text = text_generator(prompt, max_new_tokens=80)[0]["generated_text"]
    print("Generated text:\n", generated_text)

    image_pipeline = StableDiffusionPipeline.from_pretrained(
        "runwayml/stable-diffusion-v1-5", torch_dtype=torch.float16
    ).to("cuda")
    image = image_pipeline(
        f"An illustration representing {topic}, digital art", num_inference_steps=25
    ).images[0]
    image.save("content_image.png")

    gTTS(text=generated_text, lang="en").save("content_audio.mp3")
    print("Saved content_image.png and content_audio.mp3")


if __name__ == "__main__":
    main()

